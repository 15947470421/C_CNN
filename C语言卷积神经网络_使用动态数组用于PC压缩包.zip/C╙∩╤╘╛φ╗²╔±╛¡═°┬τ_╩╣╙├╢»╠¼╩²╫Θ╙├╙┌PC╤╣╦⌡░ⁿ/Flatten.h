#ifndef __FLATTEN_H__
#define __FLATTEN_H__

void Flatten(IO_size size, float* p_input, float* p_output);
void Flatten_print(IO_size size, float* p_output);

#endif
