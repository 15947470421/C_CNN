#include<stdio.h>
#include<math.h>

// ��һά����Ĺ淶��
// normalize(int size ,float* p_input)
void normalize(int size, float* p_input)
{
	float temp = 0.0;
	for (int out = 0; out < size; out++)
	{
		temp += pow(*(p_input + out), 2); // Ĭ�϶���2����
	}
	temp = sqrt(temp);

	for (int out = 0; out < size; out++)
	{
		*(p_input + out) = *(p_input + out) / temp;
	}
}

// normalize(int size ,float* p_input)
void normalize_print(int size, float* p_input)
{
	for (int out = 0; out < size; out++)
	{
		printf("input[%d] = %.4f\n", out, *(p_input + out));
	}
}
