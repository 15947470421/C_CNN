#pragma once
float distance(int size, float* p_vector_1, float* p_vector_2);