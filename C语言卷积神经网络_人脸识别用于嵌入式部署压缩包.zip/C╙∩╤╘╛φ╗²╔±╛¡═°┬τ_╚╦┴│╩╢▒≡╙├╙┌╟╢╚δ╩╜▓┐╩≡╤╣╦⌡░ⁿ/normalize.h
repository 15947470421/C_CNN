#ifndef __NORMALIZE_H__
#define __NORMALIZE_H__

void normalize(int size, float* p_input);
void normalize_print(int size, float* p_input);

#endif
