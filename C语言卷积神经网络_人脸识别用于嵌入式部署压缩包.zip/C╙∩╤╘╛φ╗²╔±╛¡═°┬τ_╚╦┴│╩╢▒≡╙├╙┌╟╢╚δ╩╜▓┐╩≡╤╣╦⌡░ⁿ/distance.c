#include<stdio.h>
#include<math.h>

// float distance(int size, float* p_vector_1, float* p_vector_2)
float distance(int size, float* p_vector_1, float* p_vector_2)
{
	float dis = 0.0;
	for (int out = 0; out < size; out++)
	{
		dis += pow(*(p_vector_1 + out) - *(p_vector_2 + out), 2); // Ĭ�϶���2����
	}
	dis = sqrt(dis);

	return dis;
};