#ifndef __RELU_H__
#define __RELU_H__

void ReLu(IO_size size, float* p_input, float* p_output);
void ReLu_print(IO_size size, float* p_output);

#endif
