#ifndef __MAX_ARR_H__
#define __MAX_ARR_H__

int max_arr(int input_size, float* p_input);

#endif
