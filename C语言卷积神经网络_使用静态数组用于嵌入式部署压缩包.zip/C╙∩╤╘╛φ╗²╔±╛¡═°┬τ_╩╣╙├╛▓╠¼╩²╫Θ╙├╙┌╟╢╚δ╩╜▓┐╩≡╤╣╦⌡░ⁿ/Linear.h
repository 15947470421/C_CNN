#ifndef __LINEAR_H__
#define __LINEAR_H__

void Linear(float* p_input, float* p_output, float* p_weight, float* p_bias, int in_features, int out_features);
void Linear_print(float* p_output, int out_features);

#endif
